const char html_index[] PROGMEM = R"(
<h3>This is the Basic Ajax Demo</h3>
<table cellpadding=4>
  <tr><td>Light:</td><td><label id='lbl_lit'></label></td></tr>
  <tr><td>Button:</td><td><label id='lbl_but'></label></td></tr>
  <tr><td>LED:</td><td><label id='lbl_led'></label></td></tr>
</table>
<script>
function w(s) {document.write(s);}
function id(s){return document.getElementById(s);}
function loadValues() {
  var xhr=new XMLHttpRequest();
  xhr.onreadystatechange=function() {
    if(xhr.readyState==4 && xhr.status==200) {
      var jd=JSON.parse(xhr.responseText);
      id('lbl_lit').innerHTML=jd.light;
      id('lbl_but').innerHTML=(jd.button)?'pressed':'released';
      id('lbl_led').innerHTML=jd.led;
    }
  };
  xhr.open('GET','js',true);
  xhr.send();
}
setInterval(loadValues, 500);
</script>
)";
